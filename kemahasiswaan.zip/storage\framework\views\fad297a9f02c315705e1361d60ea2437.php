<?php $__env->startSection('title','Hitung Prestasi - Alternatif'); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Data Alternatif</h5>
    <div class="d-flex gap-2">
      <a href="<?php echo e(route('admin.tpk.compute')); ?>" class="btn btn-outline-primary"><i class="fas fa-calculator me-1"></i> Hitung</a>
      <a href="<?php echo e(route('admin.tpk.alternatives.create')); ?>" class="btn btn-primary"><i class="fas fa-plus me-1"></i> Tambah Alternatif</a>
    </div>
  </div>
  <?php if(!empty($needs_migration)): ?>
    <div class="alert alert-warning">Tabel TPK belum dibuat. Jalankan migrasi: <code>php artisan migrate</code></div>
  <?php endif; ?>
  <?php if(session('success')): ?> <div class="alert alert-success"><?php echo e(session('success')); ?></div> <?php endif; ?>
  <div class="table-responsive">
    <table class="table table-striped align-middle">
      <thead class="table-light">
        <tr>
          <th>No.</th>
          <th>Kode Alternatif</th>
          <th>Nama</th>
          <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($c->code); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <th class="text-end">Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($i+1); ?></td>
          <td><?php echo e($a->code); ?></td>
          <td><?php echo e($a->name); ?></td>
          <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e(isset($scores[$a->id][$c->id]) ? number_format($scores[$a->id][$c->id], 2) : '-'); ?></td>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.tpk.alternatives.edit', $a->id)); ?>"><i class="fas fa-pen"></i></a>
            <form action="<?php echo e(route('admin.tpk.alternatives.destroy',$a->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus alternatif ini?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="<?php echo e(4 + count($criteria)); ?>" class="text-center text-muted">Belum ada alternatif.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/tpk/alternatives/index.blade.php ENDPATH**/ ?>