<?php $__env->startSection('title','Hitung Prestasi - SAW'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h5 class="mb-1">Hitung Prestasi</h5>
    <span class="badge bg-primary">Metode SAW</span>
    <small class="text-muted ms-2">Bobot diambil dari kriteria (hasil AHP) untuk merangking mahasiswa</small>
  </div>
  <div class="d-flex gap-2">
    <a href="<?php echo e(route('admin.tpk.criteria.index')); ?>" class="btn btn-sm btn-outline-secondary">Kelola Kriteria</a>
    <a href="<?php echo e(route('admin.tpk.alternatives.index')); ?>" class="btn btn-sm btn-outline-secondary">Kelola Alternatif</a>
    <a href="<?php echo e(route('admin.tpk.compute.export')); ?>" class="btn btn-sm btn-primary">Export CSV</a>
  </div>
</div>

<div class="card mb-3"><div class="card-body">
  <?php if(!empty($needs_migration)): ?>
    <div class="alert alert-warning">Tabel TPK belum dibuat. Jalankan migrasi: <code>php artisan migrate</code></div>
  <?php endif; ?>
  <h5 class="mb-2">Bobot</h5>
  <div class="table-responsive">
    <table class="table table-bordered align-middle mb-0">
      <thead class="table-light">
        <tr>
          <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($c->code); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </thead>
      <tbody>
        <tr>
          <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e(number_format($weights[$c->id] ?? 0, 2)); ?></td>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </tbody>
    </table>
  </div>
</div></div>

<div class="card mb-3"><div class="card-body">
  <h5 class="mb-2">Normalisasi</h5>
  <div class="table-responsive">
    <table class="table table-striped align-middle">
      <thead class="table-light">
        <tr>
          <th>Kode Alternatif</th>
          <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($c->code); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $alts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($a->code); ?></td>
            <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e(number_format($normalized[$c->id][$a->id] ?? 0, 2)); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="<?php echo e(1 + count($criteria)); ?>" class="text-center text-muted">Tidak ada alternatif.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div></div>

<div class="card"><div class="card-body">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <h5 class="mb-0">Hasil</h5>
    <a href="<?php echo e(route('admin.tpk.compute.export')); ?>" class="btn btn-sm btn-outline-primary">
      <i class="fas fa-download me-1"></i> Unduh Hasil (CSV)
    </a>
  </div>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead class="table-light">
        <tr>
          <th>Rank</th>
          <th>Kode Alternatif</th>
          <th>Nama</th>
          <th class="text-end">Hasil</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($r['rank']); ?></td>
            <td><?php echo e($r['alt']->code); ?></td>
            <td><?php echo e($r['alt']->name); ?></td>
            <td class="text-end"><?php echo e(number_format($r['score'], 2)); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="4" class="text-center text-muted">Tidak ada data.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/tpk/compute/index.blade.php ENDPATH**/ ?>