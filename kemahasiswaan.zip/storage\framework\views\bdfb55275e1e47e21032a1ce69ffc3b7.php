<?php $__env->startSection('title', 'Upload Sertifikat Prestasi'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .card-upload{max-width:720px;margin:0 auto;}
</style>
<section class="py-5">
    <div class="container">
        <div class="card shadow-sm border-0 card-upload">
            <div class="card-body">
                <h4 class="fw-bold mb-3">Upload Sertifikat</h4>
                <p class="text-muted mb-4">Prestasi: <strong><?php echo e($prestasi->kompetisi); ?></strong> (<?php echo e($prestasi->nama); ?>)</p>
                <form action="<?php echo e(route('prestasi.certificate.store', $prestasi)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Pilih berkas sertifikat (pdf/jpg/png)</label>
                        <input type="file" name="files[]" class="form-control" multiple required accept=".pdf,.jpg,.jpeg,.png">
                        <div class="form-text">Bisa lebih dari satu file, maksimum 10MB per file.</div>
                        <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['files.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('prestasi.show', $prestasi)); ?>" class="btn btn-outline-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/user/prestasi/upload_certificate.blade.php ENDPATH**/ ?>