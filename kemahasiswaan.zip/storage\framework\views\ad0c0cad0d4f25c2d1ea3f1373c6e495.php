<?php $__env->startSection('title', 'Tambah Berita Baru - Panel Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3">
            <h4 class="mb-0 fw-bold">Formulir Tambah Berita</h4>
        </div>
        <div class="card-body p-4">
            
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <form action="<?php echo e(route('admin.berita.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div class="mb-3">
                    <label for="judul" class="form-label">Judul Berita </label>
                    <input type="text" class="form-control" id="judul" name="judul"
                        value="<?php echo e(old('judul')); ?>" required>
                </div>

                
                <div class="mb-3">
                    <label for="ringkasan" class="form-label">Ringkasan </label>
                    <textarea class="form-control" id="ringkasan" name="ringkasan" rows="2" required><?php echo e(old('ringkasan')); ?></textarea>
                </div>

                
                <div class="mb-3">
                    <label for="isi" class="form-label">Isi Berita </label>
                    <textarea class="form-control" id="isi" name="isi" rows="10" required><?php echo e(old('isi')); ?></textarea>
                </div>
                
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="kategori" class="form-label">Kategori </label>
                        <select class="form-select" id="kategori" name="kategori" required>
                            <option value="Prestasi" <?php echo e(old('kategori') == 'Prestasi' ? 'selected' : ''); ?>>Prestasi</option>
                            <option value="Event" <?php echo e(old('kategori') == 'Event' ? 'selected' : ''); ?>>Event</option>
                            <option value="Pengumuman" <?php echo e(old('kategori') == 'Pengumuman' ? 'selected' : ''); ?>>Pengumuman</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="status" class="form-label">Status </label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="published" <?php echo e(old('status') == 'published' ? 'selected' : ''); ?>>Published</option>
                            <option value="draft" <?php echo e(old('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                        </select>
                    </div>
                </div>

                
                <div class="mb-3">
                    <label for="penulis" class="form-label">Penulis</label>
                    <input type="text" class="form-control" id="penulis" name="penulis"
                        value="<?php echo e(old('penulis', optional(Auth::user())->name)); ?>">
                </div>

                
                <div class="mb-3">
                    <label for="gambar" class="form-label">Gambar Utama</label>
                    <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*" onchange="previewImage(event)">
                    <small class="text-muted">Kosongkan jika tidak ingin mengupload gambar.</small>
                    
                    
                    <div class="mt-3" id="preview-container" style="display: none;">
                        <p class="mb-1 fw-semibold">Preview:</p>
                        <img id="preview-image" class="img-thumbnail" style="max-height: 250px;">
                    </div>
                </div>

                
                <div class="d-flex justify-content-end mt-4">
                    <a href="<?php echo e(route('admin.berita.index')); ?>" class="btn btn-secondary me-2">Batal</a>
                    <button type="submit" class="btn btn-primary">Simpan Berita</button>
                </div>

            </form>
        </div>
    </div>
</div>


<script>
function previewImage(event) {
    const input = event.target;
    const reader = new FileReader();

    reader.onload = function() {
        const img = document.getElementById('preview-image');
        const container = document.getElementById('preview-container');
        img.src = reader.result;
        container.style.display = 'block';
    };

    if (input.files && input.files[0]) {
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/berita/create.blade.php ENDPATH**/ ?>