<?php $__env->startSection('title', $prestasi->kompetisi . ' - Prestasi Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .fade-in-up{opacity:0;transform:translateY(16px);transition:all .6s ease}
        .fade-in-up.is-visible{opacity:1;transform:none}
        .hover-lift{transition:transform .25s ease,box-shadow .25s ease}
        .hover-lift:hover{transform:translateY(-6px);box-shadow:0 12px 28px rgba(0,0,0,.12)}
    </style>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-9">
                    <article class="card shadow-sm border-0 fade-in-up" data-animate>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                <div>
                                    <h3 class="fw-bold mb-1"><?php echo e($prestasi->kompetisi); ?></h3>
                                    <div class="text-muted small"><?php echo e($prestasi->nama); ?></div>
                                </div>
                                <div class="text-end">
                                    <?php if($prestasi->tingkat): ?>
                                        <span class="badge bg-success-subtle text-success"><?php echo e($prestasi->tingkat); ?></span>
                                    <?php endif; ?>
                                    <?php if($prestasi->peringkat): ?>
                                        <span class="badge bg-primary-subtle text-primary ms-1"><?php echo e($prestasi->peringkat); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <hr>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="text-muted small mb-1">Jurusan</div>
                                    <div><?php echo e($prestasi->jurusan ?? '-'); ?></div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-muted small mb-1">Angkatan</div>
                                    <div><?php echo e($prestasi->angkatan ?? '-'); ?></div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-muted small mb-1">Tahun</div>
                                    <div><?php echo e($prestasi->tahun ?? ($prestasi->tanggal ? $prestasi->tanggal->format('Y') : '-')); ?></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-muted small mb-1">Jenis</div>
                                    <div><?php echo e($prestasi->jenis ?? '-'); ?></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="text-muted small mb-1">Penyelenggara</div>
                                    <div><?php echo e($prestasi->penyelenggara ?? '-'); ?></div>
                                </div>
                            </div>

                            <?php if($prestasi->deskripsi): ?>
                                <hr>
                                <div>
                                    <div class="text-muted small mb-1">Deskripsi</div>
                                    <div class="pre-wrap"><?php echo nl2br(e($prestasi->deskripsi)); ?></div>
                                </div>
                            <?php endif; ?>

                            <?php
                                $isOwner = auth()->check() && (
                                    auth()->user()->role === 'admin' ||
                                    strcasecmp(trim(auth()->user()->nim ?? ''), trim($prestasi->nim ?? '')) === 0
                                );
                                $approved = $prestasi->approvedCertificates()->with('user')->get();
                            ?>

                            <?php if($approved->count()): ?>
                                <hr>
                                <div class="mb-3">
                                    <div class="text-muted small mb-1">Sertifikat Terverifikasi</div>
                                    <div class="d-flex flex-column gap-2">
                                        <?php $__currentLoopData = $approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex align-items-center justify-content-between gap-2 border rounded px-2 py-1">
                                                <div class="text-truncate">
                                                    <a href="<?php echo e($cert->url); ?>" class="text-success" target="_blank">
                                                        <i class="bi bi-file-earmark-text me-1"></i>
                                                        <?php echo e($cert->original_name ?? 'Sertifikat'); ?>

                                                    </a>
                                                    <?php ($size = $cert->size ? round($cert->size/1024,1).' KB' : ''); ?>
                                                    <?php if($size): ?><span class="text-muted small ms-1">(<?php echo e($size); ?>)</span><?php endif; ?>
                                                </div>
                                                <?php if($isOwner || (auth()->check() && auth()->user()->role === 'admin') || (auth()->id() === $cert->user_id)): ?>
                                                    <form method="POST" action="<?php echo e(route('prestasi.certificate.destroy', [$prestasi, $cert->id])); ?>" onsubmit="return confirm('Hapus sertifikat ini?');">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <a href="<?php echo e(route('prestasi.index')); ?>" class="btn btn-outline-secondary">
                                    &larr; Kembali
                                </a>
                                <div class="d-flex gap-2">
                                    <?php if($prestasi->sertifikat_url): ?>
                                        <a href="<?php echo e($prestasi->sertifikat_url); ?>" target="_blank" class="btn btn-outline-success">
                                            <i class="bi bi-file-earmark-text me-1"></i> Sertifikat
                                        </a>
                                    <?php endif; ?>
                                    <?php if($prestasi->foto_url): ?>
                                        <a href="<?php echo e($prestasi->foto_url); ?>" target="_blank" class="btn btn-outline-primary">
                                            <i class="bi bi-image me-1"></i> Lihat Foto
                                        </a>
                                    <?php endif; ?>
                                    <?php if($isOwner): ?>
                                        <a href="<?php echo e(route('prestasi.certificate.create', $prestasi)); ?>" class="btn btn-primary">
                                            <i class="bi bi-upload me-1"></i> Upload Sertifikat
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <script>
        (function(){
            const els=document.querySelectorAll('[data-animate]');
            const io=new IntersectionObserver((entries)=>{entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target);}})},{threshold:.15});
            els.forEach(el=>io.observe(el));
        })();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/user/prestasi/show.blade.php ENDPATH**/ ?>