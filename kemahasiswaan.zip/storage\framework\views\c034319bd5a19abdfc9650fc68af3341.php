<?php $__env->startSection('title', 'Detail Pelanggaran Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-xl p-6 max-w-2xl mx-auto">
    <h2 class="text-xl font-bold mb-4">Detail Pelanggaran Mahasiswa</h2>

    <div class="grid gap-3">
        <p><strong>Nama:</strong> <?php echo e($kasus->mahasiswa->nama ?? '-'); ?></p>
        <p><strong>NIM:</strong> <?php echo e($kasus->mahasiswa->nim ?? '-'); ?></p>
        <p><strong>Semester:</strong> <?php echo e($kasus->semester); ?></p>
        <p><strong>IPK:</strong> <?php echo e($kasus->ipk); ?></p>
        <p><strong>Jenis Masalah:</strong> <?php echo e($kasus->jenis_masalah); ?></p>
        <p><strong>Status Peringatan:</strong> <?php echo e($kasus->status_peringatan); ?></p>
        <p><strong>Laporan Terakhir:</strong> <?php echo e($kasus->laporan_terakhir?->format('Y-m-d')); ?></p>
        <p><strong>Keterangan:</strong> <?php echo e($kasus->keterangan); ?></p>
    </div>

    <div class="mt-5 text-right">
        <a href="<?php echo e(route('kaprodi.pelanggaran_mahasiswa.index')); ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Kaprodi.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Kaprodi/masalah_mahasiswa/show.blade.php ENDPATH**/ ?>