<?php $role = optional(Auth::user())->role; ?>
<div class="container">
    <?php if($role === 'kaprodi'): ?>
        <ul class="nav nav-tabs">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', \App\Models\MasalahMahasiswa::class)): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('kaprodi.pelanggaran_mahasiswa.*') ? 'active' : ''); ?>" href="<?php echo e(route('kaprodi.pelanggaran_mahasiswa.index')); ?>">
                        <i class="fas fa-user-times me-2"></i>Pelanggaran Mahasiswa
                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('kaprodi.pelanggaran_master.*') ? 'active' : ''); ?>" href="<?php echo e(route('kaprodi.pelanggaran_master.index')); ?>">
                    <i class="fas fa-clipboard-list me-2"></i>Master Pelanggaran
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', \App\Models\Laporan::class)): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('kaprodi.laporan.*') ? 'active' : ''); ?>" href="<?php echo e(route('kaprodi.laporan.index')); ?>">
                        <i class="fas fa-file-alt me-2"></i>Daftar Laporan
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAny', \App\Models\Laporan::class)): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('kaprodi.verifikasi.*') ? 'active' : ''); ?>" href="<?php echo e(route('kaprodi.verifikasi.index')); ?>">
                        <i class="fas fa-check-square me-2"></i>Verifikasi Laporan
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    <?php else: ?>
        <div class="alert alert-warning mb-0">
            Menu kaprodi tidak tersedia untuk role ini.
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\kemahasiswaan\resources\views/Kaprodi/partials/tabs.blade.php ENDPATH**/ ?>