<?php $__env->startSection('title', 'Kelola Prestasi - Panel Admin'); ?>

<?php use Illuminate\Support\Str; ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-1"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <!-- Header Halaman -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Kelola Prestasi Mahasiswa</h3>
        <a href="<?php echo e(route('admin.mahasiswa_berprestasi.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Tambah Prestasi
        </a>
    </div>

    <!-- Opsi Filter dan Pencarian -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.mahasiswa_berprestasi.index')); ?>">
                <div class="row g-3">
                    <!-- Kolom Pencarian -->
                    <div class="col-md-6">
                        <input 
                            type="text" 
                            name="q" 
                            value="<?php echo e(request('q')); ?>" 
                            class="form-control" 
                            placeholder="Cari prestasi berdasarkan nama, NIM, atau kompetisi...">
                    </div>

                    <!-- Filter Tingkat -->
                    <div class="col-md-3">
                        <select name="tingkat" class="form-select">
                            <option value="Semua">Semua Tingkat</option>
                            <?php $__currentLoopData = $filterTingkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tingkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tingkat); ?>" <?php echo e(request('tingkat') == $tingkat ? 'selected' : ''); ?>>
                                    <?php echo e(ucfirst($tingkat)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Filter Tahun -->
                    <div class="col-md-2">
                        <select name="tahun" class="form-select">
                            <option value="Semua">Semua Tahun</option>
                            <?php $__currentLoopData = $filterTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tahun); ?>" <?php echo e(request('tahun') == $tahun ? 'selected' : ''); ?>>
                                    <?php echo e($tahun); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Tombol Cari -->
                    <div class="col-md-1">
                        <button class="btn btn-outline-secondary w-100">Cari</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Daftar Prestasi (Dinamis) -->
    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body">
                <div class="row">
                    <!-- Icon Trophy -->
                    <div class="col-md-1 d-none d-md-flex align-items-center justify-content-center">
                        <div class="bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                            <i class="fas fa-trophy text-warning fa-lg"></i>
                        </div>
                    </div>

                    <!-- Detail Prestasi -->
                    <div class="col-md-9">
                        <h5 class="fw-bold mb-1"><?php echo e($item->nama); ?></h5>
                        <small class="text-muted"><?php echo e($item->nim); ?> - <?php echo e($item->jurusan); ?></small>
                        <div class="mt-2">
                            <p class="mb-1"><strong>Kompetisi:</strong> <?php echo e($item->kompetisi); ?></p>
                            <p class="mb-0">
                                <strong>Peringkat:</strong> <?php echo e($item->peringkat ?? '-'); ?>

                            </p>
                            <span class="badge bg-primary"><?php echo e(ucfirst($item->tingkat)); ?></span>
                            <span class="badge bg-secondary"><?php echo e($item->tahun ?? '-'); ?></span>
                        </div>
                    </div>

                    <!-- Aksi -->
                    <div class="col-md-2 d-flex align-items-center justify-content-end gap-3">
                        <?php
                            // Gunakan slug jika ada, fallback ke ID agar binding route selalu terpenuhi
                            $routeKey = $item->slug ?: $item->getKey();
                        ?>
                        <a href="<?php echo e(route('prestasi.show', $routeKey)); ?>" class="text-info" title="Lihat" target="_blank" rel="noopener">
                            <i class="fas fa-eye fa-lg"></i>
                        </a>
                        <a href="<?php echo e(route('admin.mahasiswa_berprestasi.edit', ['prestasi' => $routeKey])); ?>" class="text-secondary" title="Edit">
                            <i class="fas fa-pen fa-lg"></i>
                        </a>
                        <form 
                            action="<?php echo e(route('admin.mahasiswa_berprestasi.destroy', ['prestasi' => $routeKey])); ?>" 
                            method="POST" 
                            onsubmit="return confirm('Yakin ingin menghapus prestasi ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-link p-0 text-danger" title="Hapus" style="text-decoration: none;">
                                <i class="fas fa-trash fa-lg"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card shadow-sm border-0">
            <div class="card-body text-center py-5">
                <i class="fas fa-trophy fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">Belum Ada Data Prestasi</h5>
                <p>Silakan tambahkan data prestasi baru untuk menampilkannya di sini.</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($items->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/mahasiswa_berprestasi/index.blade.php ENDPATH**/ ?>