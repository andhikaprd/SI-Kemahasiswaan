<?php use Illuminate\Support\Str; ?>

<?php $__env->startSection('title', 'Master Pelanggaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-xl p-6">
    <div class="flex items-center justify-between mb-4">
        <div>
            <h2 class="text-xl font-semibold">Master Pelanggaran</h2>
            <p class="text-sm text-gray-500">Daftar referensi yang digunakan saat input pelanggaran mahasiswa.</p>
        </div>
        <a href="<?php echo e(route('kaprodi.pelanggaran_master.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            <i class="fas fa-plus mr-2"></i>Tambah
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-3 rounded-lg mb-3">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="min-w-full text-sm border">
            <thead class="bg-gray-50">
                <tr class="text-left text-gray-700">
                    <th class="px-4 py-2 w-12">#</th>
                    <th class="px-4 py-2">Nama</th>
                    <th class="px-4 py-2">Kategori</th>
                    <th class="px-4 py-2">Sanksi Default</th>
                    <th class="px-4 py-2 text-center w-36">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t">
                        <td class="px-4 py-2"><?php echo e($i+1); ?></td>
                        <td class="px-4 py-2">
                            <div class="font-semibold"><?php echo e($item->nama); ?></div>
                            <?php if($item->deskripsi): ?>
                                <div class="text-gray-500 text-xs"><?php echo e(Str::limit($item->deskripsi, 120)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2">
                            <span class="px-2 py-1 rounded-full text-xs font-semibold
                                <?php echo e($item->kategori === 'berat' ? 'bg-red-100 text-red-700' : ($item->kategori === 'sedang' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700')); ?>">
                                <?php echo e(ucfirst($item->kategori)); ?>

                            </span>
                        </td>
                        <td class="px-4 py-2"><?php echo e($item->sanksi_default ?: '—'); ?></td>
                        <td class="px-4 py-2 text-center">
                            <a href="<?php echo e(route('kaprodi.pelanggaran_master.edit', $item->id)); ?>" class="text-blue-600 hover:text-blue-800 mr-2"><i class="fas fa-pen"></i></a>
                            <form action="<?php echo e(route('kaprodi.pelanggaran_master.destroy', $item->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Hapus master ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-4 py-6 text-center text-gray-500">Belum ada data master.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Kaprodi.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Kaprodi/pelanggaran_master/index.blade.php ENDPATH**/ ?>