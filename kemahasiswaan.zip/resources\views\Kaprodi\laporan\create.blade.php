@extends('Kaprodi.layouts.app')

@section('title', 'Tambah Laporan')

@section('content')
<div class="bg-white shadow rounded-xl p-6">
    <h2 class="text-xl font-bold mb-4 text-gray-800">Tambah Laporan</h2>

    @if ($errors->any())
        <div class="bg-red-100 text-red-700 p-3 rounded mb-3">
            <ul class="list-disc ms-4">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('kaprodi.laporan.store') }}" method="POST" enctype="multipart/form-data" class="space-y-4">
        @csrf

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Nama Mahasiswa</label>
                <input type="text" name="nama_mahasiswa" value="{{ old('nama_mahasiswa') }}" class="mt-1 w-full border rounded-lg px-3 py-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">NIM</label>
                <input type="text" name="nim" value="{{ old('nim') }}" class="mt-1 w-full border rounded-lg px-3 py-2" required>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Judul</label>
            <input type="text" name="judul" value="{{ old('judul') }}" class="mt-1 w-full border rounded-lg px-3 py-2" required>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Periode</label>
                <input type="text" name="periode" value="{{ old('periode') }}" placeholder="Contoh: Januari - Juli 2025" class="mt-1 w-full border rounded-lg px-3 py-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Kategori</label>
                <select name="kategori" class="mt-1 w-full border rounded-lg px-3 py-2" required>
                    @foreach(['Prestasi','Akademik','Kegiatan Kemahasiswaan'] as $opt)
                        <option value="{{ $opt }}" {{ old('kategori')===$opt?'selected':'' }}>{{ $opt }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Deskripsi</label>
            <textarea name="deskripsi" rows="4" class="mt-1 w-full border rounded-lg px-3 py-2">{{ old('deskripsi') }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">File Laporan (PDF)</label>
            <input type="file" name="file_laporan" accept=".pdf" class="mt-1 w-full border rounded-lg px-3 py-2">
        </div>

        <div class="flex justify-end gap-2">
            <a href="{{ route('kaprodi.laporan.index') }}" class="px-4 py-2 bg-gray-100 rounded-lg">Batal</a>
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg">Simpan</button>
        </div>
    </form>
</div>
@endsection
