<?php $__env->startSection('title','Sertifikat Prestasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold mb-0">Sertifikat Prestasi</h4>
        <div class="d-flex gap-2">
            <span class="badge bg-success">Total: <?php echo e($counts['total'] ?? 0); ?></span>
            <span class="badge bg-success-subtle text-success">Approved: <?php echo e($counts['approved'] ?? 0); ?></span>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Prestasi</th>
                        <th>User</th>
                        <th>File</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?php echo e(optional($item->prestasi)->kompetisi); ?></div>
                            <div class="text-muted small"><?php echo e(optional($item->prestasi)->nama); ?></div>
                        </td>
                        <td>
                            <div><?php echo e(optional($item->user)->name); ?></div>
                            <div class="text-muted small"><?php echo e(optional($item->user)->email); ?></div>
                        </td>
                        <td>
                            <div class="text-muted small"><?php echo e($item->original_name); ?></div>
                            <?php ($size = $item->size ? round($item->size/1024,1).' KB' : ''); ?>
                            <?php if($size): ?><div class="text-muted small"><?php echo e($size); ?></div><?php endif; ?>
                        </td>
                        <td class="d-flex gap-1 flex-wrap">
                            <a href="<?php echo e(route('admin.prestasi_certificates.download', $item->id)); ?>" class="btn btn-sm btn-outline-secondary">Download</a>
                            <?php if($item->url): ?>
                                <a href="<?php echo e($item->url); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Lihat</a>
                            <?php endif; ?>
                            <form action="<?php echo e(route('admin.prestasi_certificates.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Hapus sertifikat ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center text-muted">Belum ada sertifikat.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php echo e($items->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/prestasi_certificates/index.blade.php ENDPATH**/ ?>