

<?php $__env->startSection('title', 'Verifikasi Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-xl p-6">
    <h2 class="text-xl font-bold mb-4 text-gray-800">Laporan Menunggu Verifikasi</h2>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-3 rounded-lg mb-3">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($laporans->isEmpty()): ?>
        <p class="text-gray-500 text-center py-6">
            Belum ada laporan yang menunggu verifikasi.
        </p>
    <?php else: ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border border-gray-200 rounded-lg p-4 shadow-sm hover:shadow-md transition">
                    <div class="flex justify-between items-start">
                        
                        <div>
                            
                            <h3 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                                <i class="fas fa-file-alt text-blue-600"></i>
                                <?php echo e($laporan->judul); ?>

                            </h3>

                            
                            <p class="text-sm text-gray-500">
                                <?php echo e($laporan->kategori ?? '-'); ?> • <?php echo e($laporan->periode ?? '-'); ?>

                            </p>

                            
                            <p class="mt-2 text-sm leading-relaxed">
                                <strong>Mahasiswa:</strong> <?php echo e($laporan->mahasiswa->nama ?? 'Nama tidak ditemukan'); ?><br>
                                <strong>NIM:</strong> <?php echo e($laporan->mahasiswa->nim ?? '-'); ?>

                            </p>

                            

                            
                            <p class="mt-2 text-sm text-gray-700">
                                <?php echo e($laporan->deskripsi ?? 'Deskripsi laporan belum tersedia.'); ?>

                            </p>

                            
                            <?php if($laporan->file_path): ?>
                                <a href="<?php echo e(route('kaprodi.verifikasi.download', $laporan)); ?>" 
                                   class="text-blue-600 text-sm mt-3 inline-flex items-center gap-1 hover:underline">
                                    <i class="fas fa-download"></i> Unduh File
                                </a>
                            <?php endif; ?>
                        </div>

                        
                        <div class="text-right text-sm text-gray-500">
                            
                            <p>
                                <strong>Tanggal Submit:</strong>
                                <?php echo e($laporan->tanggal_submit?->format('Y-m-d H:i') ?? '-'); ?>

                            </p>

                            
                            <?php
                                $status = strtolower($laporan->status);
                                $color = match($status) {
                                    'pending' => 'bg-yellow-100 text-yellow-700',
                                    'approved' => 'bg-green-100 text-green-700',
                                    'revisi' => 'bg-red-100 text-red-700',
                                    default => 'bg-gray-100 text-gray-700'
                                };
                            ?>
                            <p class="mt-1">
                                <strong>Status:</strong>
                                <span class="px-2 py-1 text-xs rounded-full <?php echo e($color); ?>">
                                    <?php echo e(ucfirst($status)); ?>

                                </span>
                            </p>
                        </div>
                    </div>

                    
                    <div class="flex justify-end gap-2 mt-4">
                        <form action="<?php echo e(route('kaprodi.verifikasi.tolak', $laporan->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="px-4 py-2 bg-red-50 text-red-600 border border-red-300 rounded-lg hover:bg-red-100 transition">
                                <i class="fas fa-times mr-1"></i> Revisi
                            </button>
                        </form>

                        <form action="<?php echo e(route('kaprodi.verifikasi.setujui', $laporan->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition">
                                <i class="fas fa-check mr-1"></i> Setujui
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Kaprodi.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Kaprodi/verifikasi/index.blade.php ENDPATH**/ ?>