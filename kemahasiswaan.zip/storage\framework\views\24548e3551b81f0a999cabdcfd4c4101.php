

<?php $__env->startSection('title', 'Daftar Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-xl p-6">

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-5 pb-4 border-b border-gray-200">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Daftar Laporan Mahasiswa</h2>
            <p class="text-gray-500 text-sm">Kelola data laporan dan status verifikasinya.</p>
        </div>
        <a href="<?php echo e(route('kaprodi.laporan.create')); ?>"
           class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
            <i class="fas fa-plus-circle mr-1"></i> Tambah Laporan
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 px-4 py-3 rounded-lg mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 gap-3">
        <div class="relative w-full sm:w-1/3">
            <input type="text" placeholder="Cari laporan..."
                class="w-full border border-gray-300 rounded-lg pl-10 pr-4 py-2 focus:ring focus:ring-blue-100 focus:border-blue-400">
            <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
        </div>

        <div class="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <select class="border border-gray-300 rounded-lg px-3 py-2 focus:ring focus:ring-blue-100 focus:border-blue-400">
                <option value="all">Semua Status</option>
                <option value="pending">Menunggu Verifikasi</option>
                <option value="approved">Disetujui</option>
                <option value="revisi">Perlu Revisi</option>
            </select>
            <form class="flex gap-2" data-base="<?php echo e(url('kaprodi/laporan/periode')); ?>">
                <select id="periodeInput" name="periode_select" class="border border-gray-300 rounded-lg px-3 py-2 focus:ring focus:ring-blue-100 focus:border-blue-400 w-40">
                    <option value="">Pilih Periode</option>
                    <?php $__currentLoopData = $periodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p); ?>"><?php echo e($p); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700" onclick="setPeriodeValue(this.form)">
                    Hasil Unduh Periode
                </button>
            </form>
        </div>
    </div>

    
    <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200 rounded-lg overflow-hidden">
            <thead class="bg-gray-50 text-gray-700">
                <tr>
                    <th class="py-3 px-4 text-left text-sm font-semibold">Laporan</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold">Dibuat Oleh</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold">Tanggal Submit</th>
                    <th class="py-3 px-4 text-left text-sm font-semibold">Status</th>
                    <th class="py-3 px-4 text-center text-sm font-semibold">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="py-3 px-4">
                            <div class="font-medium text-gray-800"><?php echo e($laporan->judul); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($laporan->kategori ?? '-'); ?></div>
                        </td>
                        <td class="py-3 px-4">
                            <div class="font-medium text-gray-800"><?php echo e($laporan->mahasiswa->nama ?? '-'); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($laporan->mahasiswa->nim ?? '-'); ?></div>
                        </td>
                        <td class="py-3 px-4 text-gray-700">
                            <?php echo e($laporan->tanggal_submit ? $laporan->tanggal_submit->format('Y-m-d H:i') : '-'); ?>

                        </td>
                        <td class="py-3 px-4">
                            <?php
                                $status = $laporan->status;
                                $color = match($status) {
                                    'pending' => 'bg-yellow-100 text-yellow-700',
                                    'approved' => 'bg-green-100 text-green-700',
                                    'revisi' => 'bg-red-100 text-red-700',
                                    default => 'bg-gray-100 text-gray-700',
                                };
                                $label = match($status) {
                                    'pending' => 'Menunggu Verifikasi',
                                    'approved' => 'Disetujui',
                                    'revisi' => 'Perlu Revisi',
                                    default => 'Belum Ditetapkan',
                                };
                            ?>
                            <span class="px-3 py-1 text-xs font-medium rounded-full <?php echo e($color); ?>">
                                <?php echo e($label); ?>

                            </span>
                        </td>
                        <td class="py-3 px-4 text-center">
                            <div class="flex justify-center gap-2">
                                <a href="<?php echo e(route('kaprodi.laporan.edit', $laporan->id)); ?>"
                                   class="text-blue-600 hover:text-blue-800" title="Edit">
                                   <i class="fas fa-edit"></i>
                                </a>
                                <?php if($laporan->file_path): ?>
                                    <a href="<?php echo e(route('kaprodi.laporan.download', $laporan->id)); ?>"
                                       class="text-gray-600 hover:text-gray-800" title="Unduh">
                                       <i class="fas fa-download"></i>
                                    </a>
                                <?php endif; ?>
                                <form action="<?php echo e(route('kaprodi.laporan.destroy', $laporan->id)); ?>" method="POST"
                                      onsubmit="return confirm('Yakin ingin menghapus laporan ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-6 text-gray-500">
                            Belum ada laporan yang tersedia.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-4">
        <?php echo e($laporans->links()); ?>

    </div>
</div>
<script>
    function setPeriodeValue(form) {
        const select = document.getElementById('periodeInput');
        if (!select || !select.value) {
            alert('Pilih periode terlebih dahulu.');
            return;
        }
        const base = form.getAttribute('data-base');
        window.location.href = `${base}/${encodeURIComponent(select.value)}/download`;
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Kaprodi.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Kaprodi/laporan/index.blade.php ENDPATH**/ ?>