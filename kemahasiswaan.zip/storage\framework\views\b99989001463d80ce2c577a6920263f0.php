

<?php $__env->startSection('title', 'Daftar Pendaftar - HIMA TI Politala'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-start mb-3 flex-wrap gap-3">
        <div>
            <h2 class="fw-bold mb-1">Daftar Pendaftar HIMA TI</h2>
            <p class="text-muted mb-0">Proses status pendaftar secara massal atau ekspor rekap CSV.</p>
        </div>
        <a href="<?php echo e(route('admin.pendaftaran.export')); ?>" class="btn btn-outline-primary d-flex align-items-center gap-2">
            <i class="fas fa-file-csv"></i><span>Ekspor CSV</span>
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <div class="card shadow-sm">
        <form method="POST" action="<?php echo e(route('admin.pendaftaran.process_bulk')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-header bg-white border-0 d-flex align-items-center gap-2 flex-wrap">
                <label class="mb-0 fw-semibold">Ubah status terpilih ke:</label>
                <select name="status" class="form-select form-select-sm" required style="max-width: 180px;">
                    <?php $__currentLoopData = ['Pending','Diterima','Ditolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-sm btn-primary d-flex align-items-center gap-1" type="submit">
                    <i class="fas fa-check"></i><span>Proses</span>
                </button>
            </div>

            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th style="width:32px;"><input type="checkbox" id="select-all"></th>
                                <th style="width:48px;">No</th>
                                <th>Nama Lengkap</th>
                                <th>NIM</th>
                                <th>Jurusan</th>
                                <th style="width:80px;">Angkatan</th>
                                <th>Email</th>
                        <th>No. WhatsApp</th>
                                <th>Divisi Pilihan</th>
                                <th>Motivasi</th>
                                <th style="width:220px;">Status & Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><input type="checkbox" name="ids[]" value="<?php echo e($p->id); ?>" class="row-check"></td>
                                    <td><?php echo e($items->firstItem() + $key); ?></td>
                                    <td><?php echo e($p->nama_lengkap); ?></td>
                                    <td><?php echo e($p->nim); ?></td>
                                    <td><?php echo e($p->jurusan); ?></td>
                                    <td><?php echo e($p->angkatan); ?></td>
                                    <td><?php echo e($p->email); ?></td>
                                    <td><?php echo e($p->no_telp); ?></td>
                                    <td><?php echo e($p->divisi_pilihan); ?></td>
                                    <td><?php echo e($p->motivasi); ?></td>
                                    <td class="text-nowrap">
                                        <form method="POST" action="<?php echo e(route('admin.pendaftaran.update', $p)); ?>" class="d-flex align-items-center gap-2 flex-wrap mb-2">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <select name="status" class="form-select form-select-sm" style="width:130px;">
                                                <?php $__currentLoopData = ['Pending','Diterima','Ditolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($status); ?>" <?php if($p->status === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button class="btn btn-sm btn-outline-primary" type="submit">Simpan</button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('admin.pendaftaran.destroy', $p)); ?>" onsubmit="return confirm('Hapus pendaftaran ini?')" class="mb-0">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-outline-danger w-100" type="submit">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="11" class="text-center">Belum ada pendaftar</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white border-0">
                <?php echo e($items->links()); ?>

            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const selectAll = document.getElementById('select-all');
    if (selectAll) {
        selectAll.addEventListener('change', (e) => {
            document.querySelectorAll('.row-check').forEach(cb => cb.checked = e.target.checked);
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/pendaftaran/index.blade.php ENDPATH**/ ?>