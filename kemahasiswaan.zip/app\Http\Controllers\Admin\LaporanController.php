<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Laporan;
use App\Models\MahasiswaBerprestasi;
use App\Models\Berita;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class LaporanController extends Controller
{
    public function __construct()
    {
        $this->authorizeResource(Laporan::class, 'laporan');
    }

    /**
     * Tampilkan daftar laporan dan statistik ringkasan.
     */
    public function index()
    {
        $laporans = Laporan::latest()->paginate(10);

        return view('Admin.laporan.index', [
            'laporans' => $laporans,
            'totalPrestasi' => MahasiswaBerprestasi::count() ?? 0,
            'totalPengguna' => User::count() ?? 0,
            'totalBerita' => Berita::count() ?? 0,
            'totalLaporan' => Laporan::count(),
        ]);
    }

    /**
     * Tampilkan form tambah laporan.
     */
    public function create()
    {
        return view('Admin.laporan.create');
    }

    /**
     * Simpan laporan baru.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama_mahasiswa' => 'required|string|max:255',
            'nim' => 'required|string|max:30',
            'judul' => 'required|string|max:255',
            'periode' => 'required|string|max:100',
            'kategori' => 'required|string|max:100',
            'deskripsi' => 'nullable|string',
            'file_laporan' => 'nullable|file|mimes:pdf|max:5120', // 5MB
        ]);

        $pathFile = null;
        if ($request->hasFile('file_laporan')) {
            try {
                $pathFile = $request->file('file_laporan')->store('laporan', 'local');
            } catch (\Throwable $e) {
                Log::error('laporan_upload_failed', [
                    'scope' => 'admin',
                    'action' => 'store',
                    'user_id' => auth()->id(),
                    'error' => $e->getMessage(),
                ]);
                return back()->withErrors(['file_laporan' => 'Gagal menyimpan file laporan, coba lagi.']);
            }
        }

        // Temukan atau buat Mahasiswa dari NIM yang diinput
        $mahasiswa = \App\Models\Mahasiswa::firstOrCreate(
            ['nim' => $request->nim],
            ['nama' => $request->nama_mahasiswa]
        );
        // Sinkronkan nama jika berbeda
        if ($mahasiswa->nama !== $request->nama_mahasiswa) {
            $mahasiswa->nama = $request->nama_mahasiswa;
            $mahasiswa->save();
        }
        $mahasiswaId = $mahasiswa->id;
        $mataKuliahId = \App\Models\MataKuliah::value('id');

        if (!$mataKuliahId) {
            $mataKuliah = \App\Models\MataKuliah::create([
                'nama' => 'Umum',
                'kode' => 'UMUM',
            ]);
            $mataKuliahId = $mataKuliah->id;
        }

        // $mahasiswaId sudah pasti terisi dari input pengguna

        Laporan::create([
            'mahasiswa_id' => $mahasiswaId,
            'mata_kuliah_id' => $mataKuliahId,
            'judul' => $request->judul,
            'periode' => $request->periode,
            'kategori' => $request->kategori,
            'status' => 'pending',
            'deskripsi' => $request->deskripsi,
            'file_path' => $pathFile,
        ]);

        return redirect()->route('admin.laporan.index')->with('success', 'Laporan berhasil ditambahkan!');
    }

    /**
     * Tampilkan form edit laporan.
     */
    public function edit(Laporan $laporan)
    {
        return view('Admin.laporan.edit', compact('laporan'));
    }

    /**
     * Detail laporan (admin).
     */
    public function show(Laporan $laporan)
    {
        return view('Admin.laporan.show', compact('laporan'));
    }

    /**
     * Update data laporan.
     */
    public function update(Request $request, Laporan $laporan)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'periode' => 'required|string|max:100',
            'kategori' => 'required|string|max:100',
            'deskripsi' => 'nullable|string',
            'file_laporan' => 'nullable|file|mimes:pdf|max:5120',
        ]);

        $data = $request->only(['judul', 'periode', 'kategori', 'deskripsi']);

        // Ganti file jika ada upload baru
        if ($request->hasFile('file_laporan')) {
            $this->deleteFileIfExists($laporan->file_path);
            try {
                $data['file_path'] = $request->file('file_laporan')->store('laporan', 'local');
            } catch (\Throwable $e) {
                Log::error('laporan_upload_failed', [
                    'scope' => 'admin',
                    'action' => 'update',
                    'laporan_id' => $laporan->id,
                    'user_id' => auth()->id(),
                    'error' => $e->getMessage(),
                ]);
                return back()->withErrors(['file_laporan' => 'Gagal menyimpan file laporan, coba lagi.']);
            }
        }

        $laporan->update($data);

        return redirect()->route('admin.laporan.index')->with('success', 'Laporan berhasil diperbarui!');
    }

    /**
     * Hapus laporan.
     */
    public function destroy(Laporan $laporan)
    {
        $this->deleteFileIfExists($laporan->file_path);

        $laporan->delete();

        return redirect()->route('admin.laporan.index')->with('success', 'Laporan berhasil dihapus!');
    }

    public function download(Laporan $laporan)
    {
        if (!$laporan->file_path) {
            Log::warning('laporan_download_missing_path', [
                'scope' => 'admin',
                'laporan_id' => $laporan->id,
                'user_id' => auth()->id(),
            ]);
            abort(404);
        }
        $disk = Storage::disk('local')->exists($laporan->file_path) ? 'local' : (Storage::disk('public')->exists($laporan->file_path) ? 'public' : null);
        if (!$disk) {
            Log::warning('laporan_download_file_not_found', [
                'scope' => 'admin',
                'laporan_id' => $laporan->id,
                'user_id' => auth()->id(),
                'path' => $laporan->file_path,
            ]);
            abort(404);
        }
        $filename = basename($laporan->file_path) ?: 'laporan.pdf';
        return Storage::disk($disk)->download($laporan->file_path, $filename);
    }

    private function deleteFileIfExists(?string $path): void
    {
        if (!$path) {
            return;
        }
        Storage::disk('local')->delete($path);
        Storage::disk('public')->delete($path); // fallback untuk file lama
    }
}
