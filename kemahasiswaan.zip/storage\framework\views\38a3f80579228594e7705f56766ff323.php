<?php $__env->startSection('title','Tambah Kriteria'); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
  <h5 class="mb-3">Tambah Data Kriteria</h5>
  <?php if($errors->any()): ?><div class="alert alert-danger"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
  <form method="POST" action="<?php echo e(route('admin.tpk.criteria.store')); ?>" class="row g-3">
    <?php echo csrf_field(); ?>
    <div class="col-md-2"><label class="form-label">Kode</label><input name="code" class="form-control" placeholder="C1" value="<?php echo e(old('code')); ?>" required></div>
    <div class="col-md-6"><label class="form-label">Kriteria</label><input name="name" class="form-control" placeholder="Nama Kriteria" value="<?php echo e(old('name')); ?>" required></div>
    <div class="col-md-2"><label class="form-label">Nilai Bobot</label><input name="weight" type="number" step="0.01" class="form-control" placeholder="50" value="<?php echo e(old('weight')); ?>" required></div>
    <div class="col-md-2"><label class="form-label">Jenis</label>
      <select name="type" class="form-select" required>
        <option value="benefit" <?php if(old('type')==='benefit'): echo 'selected'; endif; ?>>Benefit</option>
        <option value="cost" <?php if(old('type')==='cost'): echo 'selected'; endif; ?>>Cost</option>
      </select>
    </div>
    <div class="col-md-2"><label class="form-label">Urutan</label><input name="order" type="number" min="0" class="form-control" value="<?php echo e(old('order',0)); ?>"></div>
    <div class="col-12">
      <button class="btn btn-primary">Create</button>
      <a class="btn btn-light" href="<?php echo e(route('admin.tpk.criteria.index')); ?>">Kembali</a>
    </div>
  </form>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/tpk/criteria/create.blade.php ENDPATH**/ ?>