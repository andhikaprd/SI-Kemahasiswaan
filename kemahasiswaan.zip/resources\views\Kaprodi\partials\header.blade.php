<div class="bg-blue-700 text-white p-4 rounded-t-xl">
    <h1 class="text-2xl font-bold">Panel Kaprodi</h1>
    <p class="text-sm text-blue-100">Kelola Data Mahasiswa dan Verifikasi Laporan</p>
</div>
