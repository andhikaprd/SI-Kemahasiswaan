<?php $__env->startSection('title', 'Kelola Berita - Panel Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Kelola Berita</h3>
        <a href="<?php echo e(route('admin.berita.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Berita
        </a>
    </div>

    <!-- Alert Success -->
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Filter & Pencarian -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.berita.index')); ?>">
                <div class="row g-3">
                    <div class="col-md-5">
                        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                            placeholder="Cari berita berdasarkan judul atau isi...">
                    </div>
                    <div class="col-md-3">
                        <select name="kategori" class="form-select">
                            <option value="">Semua Kategori</option>
                            <option value="Prestasi" <?php echo e(request('kategori') == 'Prestasi' ? 'selected' : ''); ?>>Prestasi</option>
                            <option value="Event" <?php echo e(request('kategori') == 'Event' ? 'selected' : ''); ?>>Event</option>
                            <option value="Pengumuman" <?php echo e(request('kategori') == 'Pengumuman' ? 'selected' : ''); ?>>Pengumuman</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="status" class="form-select">
                            <option value="">Semua Status</option>
                            <option value="published" <?php echo e(request('status') == 'published' ? 'selected' : ''); ?>>Published</option>
                            <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-outline-secondary w-100">Cari</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Daftar Berita -->
    <?php $__empty_1 = true; $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body">
                <div class="row">
                    <!-- Gambar -->
                    <div class="col-md-2 text-center mb-3 mb-md-0">
                        <?php if($berita->gambar): ?>
                            <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" alt="gambar"
                                class="img-fluid rounded shadow-sm" style="max-height:100px;object-fit:cover;">
                        <?php else: ?>
                            <div class="bg-light border rounded d-flex align-items-center justify-content-center"
                                 style="height:100px;">
                                <i class="fas fa-image text-muted fa-lg"></i>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Info Berita -->
                    <div class="col-md-8">
                        <h5 class="fw-bold mb-1"><?php echo e($berita->judul); ?></h5>
                        <div class="d-flex small text-muted mb-2 flex-wrap">
                            <span class="me-3"><i class="fas fa-user me-1"></i> <?php echo e($berita->penulis ?? 'Admin'); ?></span>
                            <span class="me-3"><i class="fas fa-calendar-alt me-1"></i> 
                                <?php echo e($berita->tanggal_publikasi ? $berita->tanggal_publikasi->translatedFormat('d F Y H:i') : '-'); ?>

                            </span>
                        </div>
                        <p class="text-muted mb-1"><?php echo e(Str::limit($berita->ringkasan, 120)); ?></p>
                        <div>
                            <span class="badge bg-warning text-dark"><?php echo e($berita->kategori ?? 'Umum'); ?></span>
                            <span class="badge bg-<?php echo e($berita->status == 'published' ? 'success' : 'secondary'); ?>">
                                <?php echo e(ucfirst($berita->status)); ?>

                            </span>
                        </div>
                    </div>

                    <!-- Aksi -->
                    <div class="col-md-2 d-flex align-items-center justify-content-end gap-3">
                        <a href="<?php echo e(route('admin.berita.show', $berita)); ?>"
                           class="text-info" title="Lihat">
                            <i class="fas fa-eye fa-lg"></i>
                        </a>
                        <a href="<?php echo e(route('admin.berita.edit', $berita->id)); ?>"
                           class="text-primary" title="Edit">
                            <i class="fas fa-pen fa-lg"></i>
                        </a>
                        <form action="<?php echo e(route('admin.berita.destroy', $berita->id)); ?>"
                              method="POST" onsubmit="return confirm('Hapus berita ini?');" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-link p-0 text-danger" title="Hapus" style="text-decoration: none;">
                                <i class="fas fa-trash fa-lg"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card shadow-sm border-0">
            <div class="card-body text-center py-5">
                <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">Belum Ada Berita</h5>
                <p>Silakan tambahkan berita baru untuk menampilkannya di sini.</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Paginasi -->
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($beritas->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/berita/index.blade.php ENDPATH**/ ?>