<?php $__env->startSection('title','Edit Alternatif'); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
  <h5 class="mb-3">Edit Data Alternatif</h5>
  <?php if($errors->any()): ?><div class="alert alert-danger"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
  <form method="POST" action="<?php echo e(route('admin.tpk.alternatives.update', $alternative->id)); ?>" class="row g-3">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="col-md-3"><label class="form-label">Kode</label><input name="code" class="form-control" value="<?php echo e(old('code',$alternative->code)); ?>" required></div>
    <div class="col-md-5"><label class="form-label">Nama</label><input name="name" class="form-control" value="<?php echo e(old('name',$alternative->name)); ?>" required></div>
    <div class="col-md-12"><label class="form-label">Catatan</label><input name="note" class="form-control" value="<?php echo e(old('note',$alternative->note)); ?>"></div>

    <div class="col-12"><hr><strong>Nilai Kriteria</strong></div>
    <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3">
        <label class="form-label"><?php echo e($c->code); ?> (<?php echo e($c->name); ?>)</label>
        <input type="number" step="0.0001" name="crit[<?php echo e($c->id); ?>]" class="form-control" value="<?php echo e(old('crit.'.$c->id, $values[$c->id] ?? '')); ?>" placeholder="Nilai">
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="col-12">
      <button class="btn btn-primary">Simpan</button>
      <a href="<?php echo e(route('admin.tpk.alternatives.index')); ?>" class="btn btn-light">Kembali</a>
    </div>
  </form>
</div></div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\kemahasiswaan\resources\views/Admin/tpk/alternatives/edit.blade.php ENDPATH**/ ?>